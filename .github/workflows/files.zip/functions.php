<?php
/**
 * HIGHSTREET OFFICIAL child theme functions
 */

if ( ! defined( 'HS_THEME_VERSION' ) ) {
    define( 'HS_THEME_VERSION', '1.0.0' );
}

/**
 * Enqueue styles & scripts
 */
function hs_enqueue_assets() {
    // Parent theme already enqueued by WordPress; ensure dependency ordering
    wp_enqueue_style( 'hs-main', get_stylesheet_directory_uri() . '/assets/css/main.css', array(), HS_THEME_VERSION );
    wp_enqueue_style( 'hs-woocommerce', get_stylesheet_directory_uri() . '/assets/css/woocommerce.css', array(), HS_THEME_VERSION );
    wp_enqueue_script( 'hs-mega-menu', get_stylesheet_directory_uri() . '/assets/js/mega-menu.js', array('jquery'), HS_THEME_VERSION, true );
    wp_enqueue_script( 'hs-custom', get_stylesheet_directory_uri() . '/assets/js/custom.js', array('jquery'), HS_THEME_VERSION, true );

    // Localize for AJAX
    wp_localize_script( 'hs-custom', 'hs_ajax', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'hs_ajax_nonce' ),
    ) );
}
add_action( 'wp_enqueue_scripts', 'hs_enqueue_assets', 20 );

/**
 * Theme setup
 */
function hs_theme_setup() {
    // WooCommerce support
    add_theme_support( 'woocommerce' );

    // Image sizes can be registered here
    add_image_size( 'hs-portrait', 600, 900, true );

    // Register menus
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'highstreet-official' ),
        'footer'  => __( 'Footer Menu', 'highstreet-official' ),
    ) );
}
add_action( 'after_setup_theme', 'hs_theme_setup' );

/**
 * Include modular files
 */
require_once get_stylesheet_directory() . '/inc/customizer.php';
require_once get_stylesheet_directory() . '/inc/mega-menu.php';
require_once get_stylesheet_directory() . '/inc/performance.php';

/**
 * Example AJAX handler (safe, nonce-checked stub)
 */
function hs_ajax_example() {
    check_ajax_referer( 'hs_ajax_nonce', 'nonce' );

    // Example: handle request
    wp_send_json_success( array( 'message' => 'AJAX working' ) );
}
add_action( 'wp_ajax_hs_example', 'hs_ajax_example' );
add_action( 'wp_ajax_nopriv_hs_example', 'hs_ajax_example' );