<?php
/**
 * Template Name: HS Homepage (Custom)
 */
get_header();
?>

<section class="homepage-hero">
  <div class="container">
    <h1>HIGHSTREET OFFICIAL</h1>
    <p>Premium multi-category e-commerce platform built with Storefront + WooCommerce.</p>
  </div>
</section>

<section class="homepage-products">
  <div class="container">
    <?php
      // Example: show latest products (use WooCommerce shortcodes or custom loop)
      echo do_shortcode('[products limit="8" columns="4" orderby="date" order="DESC"]');
    ?>
  </div>
</section>

<?php
get_footer();