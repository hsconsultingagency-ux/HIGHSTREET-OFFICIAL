<?php
/**
 * Header template (stub)
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="site-header">
  <div class="container">
    <div class="site-branding">
      <a href="<?php echo esc_url( home_url('/') ); ?>">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/logo.png' ); ?>" alt="<?php bloginfo('name'); ?>">
      </a>
    </div>

    <nav class="primary-navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'highstreet-official' ); ?>">
      <?php
        wp_nav_menu( array(
          'theme_location' => 'primary',
          'container'      => false,
        ) );
      ?>
    </nav>
  </div>
</header>
<main id="site-content">