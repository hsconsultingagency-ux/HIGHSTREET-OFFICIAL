<?php
/**
 * Footer template (stub)
 */
?>
</main><!-- #site-content -->
<footer class="site-footer">
  <div class="container">
    <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
    <?php
      wp_nav_menu( array(
        'theme_location' => 'footer',
        'container'      => false,
      ) );
    ?>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>