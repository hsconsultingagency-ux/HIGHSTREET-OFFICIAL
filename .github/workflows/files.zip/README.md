```markdown
HIGHSTREET OFFICIAL — Brand asset package
=========================================

Files included (save each as the filename listed):
- logo-primary.svg         — Primary black background hero SVG (use for hero banners, PNG exports)
- logo-transparent.svg     — Transparent background full-size SVG (most flexible for site use)
- logo-horizontal.svg      — Header / navigation horizontal variant (icon left, wordmark right)
- favicon.svg              — Square favicon SVG (convert to .ico/.png as needed)

Design goals
------------
- Luxury/premium tone with a gold metallic gradient and minimal, elegant shopping-bag device.
- Distinctive, corporate-friendly wordmark (Cinzel serif recommended) — international and upscale.
- Scalable vector assets for crisp rendering on all screens and retina displays.

Usage & upload
--------------
- Upload the SVGs directly to WordPress Media Library or to your /wp-content/themes/<theme>/assets/images/ directory.
- For theme header: use logo-horizontal.svg (ideal for nav bars).
- For hero/banner or retina displays: use logo-primary.svg or export as PNG 2400×2400 px for large hero use.
- For product labels and stamps: use logo-transparent.svg (SVG keeps file size small and vector sharp).

Export to PNG/ICO (recommended commands)
----------------------------------------
Using ImageMagick (convert/ magick):
- Export large PNG (hero):
  magick logo-primary.svg -background transparent -resize 2400x2400 logo-primary-2400.png

- Export web PNGs (retina and standard):
  magick logo-transparent.svg -background none -resize 1200x1200 logo-1200.png
  magick logo-transparent.svg -background none -resize 600x600  logo-600.png
  magick logo-transparent.svg -background none -resize 300x300  logo-300.png

- Generate favicon.ico (multiple sizes in one file):
  magick logo-transparent.svg -background none -resize 64x64 favicon-64.png
  magick logo-transparent.svg -background none -resize 32x32 favicon-32.png
  magick favicon-64.png favicon-32.png -colors 256 favicon.ico

Using Inkscape (CLI):
- Inkscape --export-type="png" --export-filename=logo-1200.png --export-width=1200 logo-transparent.svg

HTML head snippet (example)
---------------------------
<link rel="icon" href="/path/to/favicon.ico" sizes="32x32" />
<link rel="icon" type="image/svg+xml" href="/path/to/favicon.svg" />
<link rel="apple-touch-icon" href="/path/to/logo-180.png" />

<meta property="og:image" content="https://yourdomain.com/path/to/logo-1200.png" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:image" content="https://yourdomain.com/path/to/logo-1200.png" />

Brand guidelines (quick)
------------------------
Colors (gold family):
- Light gold: #f5dd9a
- Mid gold:   #d8b25a
- Deep gold:  #b6862a
Background:
- Signature black: #0b0b0b
Type:
- Primary recommendation: Cinzel (Google Fonts) or Cinzel Decorative for headings.
- Fallback: Georgia, 'Times New Roman', serif.
Spacing:
- Keep generous whitespace around the mark — at least the height of the "OFFICIAL" line as clearspace.

Accessibility & SEO
-------------------
- Provide descriptive alt attributes, e.g. alt="HIGHSTREET OFFICIAL — Luxury fashion and lifestyle"
- Use the transparent SVG for logos on content pages to let text/background contrast remain accessible.
- Ensure favicon is available as .ico and PNG for older browsers.

If you'd like
--------------
- I can generate PNG/ICO files for you and pack everything into a downloadable ZIP — tell me preferred output sizes.
- I can also provide a CSS header block and a ready WordPress Customizer snippet to automatically select the horizontal logo in your theme header.