/**
 * Mega menu logic stub
 * - toggles submenus and handles accessibility
 */

(function($){
  $(function(){
    $('.hs-mega-toggle').on('click', function(e){
      e.preventDefault();
      $(this).next('.hs-mega-panel').toggleClass('open');
    });
  });
})(jQuery);