/**
 * Custom theme JS
 * - small helper functions
 * - AJAX examples
 */

(function($){
  $(document).ready(function(){
    // Example AJAX call
    $('#hs-ajax-test').on('click', function(e){
      e.preventDefault();
      $.post(hs_ajax.ajax_url, {
        action: 'hs_example',
        nonce: hs_ajax.nonce
      }, function(response){
        if (response.success) {
          alert(response.data.message);
        } else {
          alert('AJAX failed');
        }
      });
    });

    // Lazy-loading hint (IntersectionObserver can be expanded)
    if ('IntersectionObserver' in window) {
      const imgs = document.querySelectorAll('img[data-src]');
      const io = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src;
            img.removeAttribute('data-src');
            io.unobserve(img);
          }
        });
      });
      imgs.forEach(img => io.observe(img));
    }
  });
})(jQuery);