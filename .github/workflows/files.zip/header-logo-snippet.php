<?php
// Place inside templates/header.php where logo should appear
echo hs_get_logo_markup();
?>