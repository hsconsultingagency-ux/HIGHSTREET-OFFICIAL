HIGHSTREET OFFICIAL — Upload & install instructions
--------------------------------------------------

Files to upload (place in either Media Library or your theme assets folder):
- logo-primary.svg
- logo-transparent.svg
- logo-horizontal.svg
- favicon.svg

Recommended server paths (choose one method):
A) Theme assets (preferred for theme-controlled logos):
   /wp-content/themes/your-active-theme/assets/images/logo-primary.svg
   /wp-content/themes/your-active-theme/assets/images/logo-transparent.svg
   /wp-content/themes/your-active-theme/assets/images/logo-horizontal.svg
   /wp-content/themes/your-active-theme/assets/images/favicon.svg

B) WordPress Media Library (simpler, use Appearance > Customize to select):
   Upload each SVG via Media > Add New

Generating PNG / ICO exports (ImageMagick)
- Large hero PNG (2400px):
  magick logo-primary.svg -background none -resize 2400x2400 logo-primary-2400.png

- Retina / web PNGs:
  magick logo-transparent.svg -background none -resize 1200x1200 logo-1200.png
  magick logo-transparent.svg -background none -resize 600x600  logo-600.png
  magick logo-transparent.svg -background none -resize 300x300  logo-300.png

- Favicon set & .ico:
  magick logo-transparent.svg -background none -resize 64x64 favicon-64.png
  magick logo-transparent.svg -background none -resize 32x32 favicon-32.png
  magick favicon-64.png favicon-32.png -colors 256 favicon.ico

Using Inkscape (CLI):
- Inkscape --export-type="png" --export-filename=logo-1200.png --export-width=1200 logo-transparent.svg

WordPress steps to add logo via Customizer:
1. Upload the recommended horizontal logo or PNG to Media Library (Appearance > Customize > Site Identity > Select logo).
2. Upload favicon (.ico or 32×32 PNG) via Customize > Site Identity > Site Icon.
3. If you keep file in theme assets, use the header.php snippet below to reference it.

If you want, I can package PNG/ICO sizes into a ZIP and give a download link — tell me which sizes you want (default above is fine).