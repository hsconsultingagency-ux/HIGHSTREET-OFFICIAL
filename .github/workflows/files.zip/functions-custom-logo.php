<?php
/**
 * HIGHSTREET OFFICIAL — Custom logo & favicon helper
 * Add this to your child theme's functions.php or include as a small plugin.
 */

/* 1) Add theme support for custom logo with recommended sizes */
function hs_official_setup() {
    add_theme_support( 'custom-logo', array(
        'height'      => 78,
        'width'       => 260,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array( 'site-title', 'site-description' ),
    ) );
}
add_action( 'after_setup_theme', 'hs_official_setup' );

/* 2) Fallback: if there's no custom logo set in Customizer, output our horizontal SVG from the theme folder */
function hs_get_logo_markup() {
    if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
        return get_custom_logo();
    }

    // Fallback to horizontal logo in child theme assets (ensure file exists)
    $logo_path = get_stylesheet_directory_uri() . '/assets/images/logo-horizontal.svg';
    $html = '<a class="site-branding" href="'. esc_url( home_url('/') ) .'" title="'. esc_attr( get_bloginfo( 'name' ) ) .'">';
    $html .= '<img src="'. esc_url( $logo_path ) .'" alt="'. esc_attr( get_bloginfo( 'name' ) ) .'" style="max-height:60px;">';
    $html .= '</a>';
    return $html;
}

/* 3) Output favicon svg and png fallbacks in head if not handled by theme */
function hs_output_favicon() {
    $favicon_uri = get_stylesheet_directory_uri() . '/assets/images/favicon.svg';
    // SVG
    echo '<link rel="icon" type="image/svg+xml" href="' . esc_url( $favicon_uri ) . '">' . "\n";
    // PNG fallback (32x32)
    $png32 = get_stylesheet_directory_uri() . '/assets/images/favicon-32.png';
    echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( $png32 ) . '">' . "\n";
}
add_action( 'wp_head', 'hs_output_favicon' );