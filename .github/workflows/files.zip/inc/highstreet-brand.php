<?php
/**
 * HIGHSTREET OFFICIAL — Single-file brand assets + helper functions
 *
 * Purpose:
 * - Provide inline SVG brand assets (horizontal, transparent, primary, favicon)
 * - Output favicon link tags (SVG data URI) in <head>
 * - Provide hs_get_logo_markup() and hs_the_logo() helpers for theme header
 * - Provide [hsbp_logo] shortcode to insert logo in posts/templates
 *
 * How to install:
 * 1. Save this file to your active theme folder under: /wp-content/themes/your-theme/inc/highstreet-brand.php
 *    (create the 'inc' folder if it doesn't exist)
 * 2. Include it from your theme's functions.php (add one line):
 *      require_once get_stylesheet_directory() . '/inc/highstreet-brand.php';
 * 3. Use in header.php where you want the logo:
 *      <?php echo hs_get_logo_markup(); ?>
 *    or echo hs_the_logo(); or place shortcode [hsbp_logo] in editor.
 *
 * Notes:
 * - This single file avoids plugins and additional asset files by embedding SVGs as strings and serving them inline / as data URIs.
 * - If you prefer to keep separate PNG/SVG files on disk, we can provide an alternate variant to write files to the theme folder (requires file permissions).
 *
 * Security: No credentials or external network calls. SVGs are static strings output as markup or encoded data-URIs.
 */

/* Prevent direct access */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'HSBP_VERSION' ) ) {
	define( 'HSBP_VERSION', '1.0.0' );
}

/* ------------------------------------------------------------------------
 * SVG assets (embedded)
 * ----------------------------------------------------------------------*/

/* Horizontal header variant (compact, icon left, wordmark right) */
$hsbp_svg_logo_horizontal = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2000 600" width="2000" height="600" role="img" aria-hidden="false" focusable="false">
  <defs>
    <linearGradient id="gH" x1="0" x2="0" y1="0" y2="1">
      <stop offset="0%" stop-color="#f5dd9a"/>
      <stop offset="100%" stop-color="#b6862a"/>
    </linearGradient>
    <style><![CDATA[
      .brand{font-family:Cinzel, Georgia, serif}
    ]]></style>
  </defs>

  <!-- Icon (left) -->
  <g transform="translate(60,40) scale(0.9)">
    <path d="M80 60 h160 l20 210 a10 10 0 0 1 -10 12 H70 a10 10 0 0 1 -10 -12 z"
          fill="url(#gH)" stroke="#8f6b2b" stroke-width="4" stroke-linejoin="round"/>
    <path d="M110 60 q40 -45 120 0" fill="none" stroke="#cf9f45" stroke-width="10" stroke-linecap="round"/>
  </g>

  <!-- Text (right) -->
  <text x="420" y="180" class="brand" font-size="96" fill="#d9b46a" font-weight="700" letter-spacing="5">
    HIGHSTREET
  </text>
  <text x="420" y="260" class="brand" font-size="40" fill="#e7c87f" letter-spacing="8">
    OFFICIAL
  </text>
</svg>
SVG;

/* Transparent full-size logo (flexible for hero use) */
$hsbp_svg_logo_transparent = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 1200" width="1200" height="1200" role="img" aria-hidden="false" focusable="false">
  <defs>
    <linearGradient id="gT" x1="0" x2="0" y1="0" y2="1">
      <stop offset="0%" stop-color="#f6e0ae"/>
      <stop offset="50%" stop-color="#d8b25a"/>
      <stop offset="100%" stop-color="#b6862a"/>
    </linearGradient>
    <style><![CDATA[
      .brand{font-family:Cinzel, Georgia, serif}
    ]]></style>
  </defs>

  <!-- Icon group -->
  <g transform="translate(300,150)">
    <path d="M150 120 h300 l40 420 a20 20 0 0 1 -20 24 H130 a20 20 0 0 1 -20 -24 z"
          fill="url(#gT)" stroke="#a67c2e" stroke-width="5" stroke-linejoin="round"/>
    <circle cx="190" cy="80" r="16" fill="#b78b33"/>
    <circle cx="410" cy="80" r="16" fill="#b78b33"/>
    <path d="M200 80 q60 -70 200 0" fill="none" stroke="#cf9e44" stroke-width="14" stroke-linecap="round"/>
  </g>

  <text x="600" y="760" text-anchor="middle" class="brand" font-size="110" fill="#cfaE6a" font-weight="700" letter-spacing="6">
    HIGHSTREET
  </text>

  <text x="600" y="860" text-anchor="middle" class="brand" font-size="48" fill="#e0c480" letter-spacing="10">
    OFFICIAL
  </text>
</svg>
SVG;

/* Primary hero logo for dark background (includes background) */
$hsbp_svg_logo_primary = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 1200" width="1200" height="1200" role="img" aria-hidden="false" focusable="false">
  <defs>
    <linearGradient id="gP" x1="0" x2="0" y1="0" y2="1">
      <stop offset="0%" stop-color="#f5dd9a"/>
      <stop offset="50%" stop-color="#d8b25a"/>
      <stop offset="100%" stop-color="#b6862a"/>
    </linearGradient>
    <style><![CDATA[
      .brand{font-family:Cinzel, Georgia, serif}
    ]]></style>
  </defs>

  <!-- Background -->
  <rect width="100%" height="100%" fill="#0b0b0b"/>

  <!-- Shopping bag icon (stylized) -->
  <g transform="translate(300,150)">
    <path d="M150 120 h300 l40 420 a20 20 0 0 1 -20 24 H130 a20 20 0 0 1 -20 -24 z"
          fill="url(#gP)" stroke="#8f6b2b" stroke-width="6" stroke-linejoin="round"/>
    <circle cx="190" cy="80" r="18" fill="#b38633"/>
    <circle cx="410" cy="80" r="18" fill="#b38633"/>
    <path d="M200 80 q60 -70 200 0" fill="none" stroke="#cf9f45" stroke-width="18" stroke-linecap="round"/>
  </g>

  <!-- Wordmark: HIGHSTREET -->
  <text x="600" y="760" text-anchor="middle" class="brand" font-size="110" fill="#d9b46a" font-weight="700" letter-spacing="6">
    HIGHSTREET
  </text>

  <!-- Subtext: OFFICIAL -->
  <text x="600" y="860" text-anchor="middle" class="brand" font-size="48" fill="#e7c87f" letter-spacing="10">
    OFFICIAL
  </text>
</svg>
SVG;

/* Favicon small (square) */
$hsbp_svg_favicon = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64" role="img" aria-hidden="false" focusable="false">
  <defs>
    <linearGradient id="gFav" x1="0" x2="0" y1="0" y2="1">
      <stop offset="0%" stop-color="#f5dd9a"/>
      <stop offset="100%" stop-color="#b6862a"/>
    </linearGradient>
  </defs>
  <rect width="64" height="64" rx="8" fill="#0b0b0b"/>
  <g transform="translate(8,6)" fill="url(#gFav)">
    <rect x="6" y="10" width="36" height="30" rx="4"/>
    <path d="M12 10 q8 -11 24 0" fill="none" stroke="url(#gFav)" stroke-width="3" stroke-linecap="round"/>
  </g>
</svg>
SVG;

/* ------------------------------------------------------------------------
 * Helper: convert SVG string to safe data URI (SVG must be raw, then rawurlencode)
 * ----------------------------------------------------------------------*/
if ( ! function_exists( 'hsbp_svg_to_data_uri' ) ) {
	function hsbp_svg_to_data_uri( $svg_string ) {
		// Remove newlines and collapse multiple spaces for smaller URI
		$svg_min = preg_replace( "/\s+/", ' ', trim( $svg_string ) );
		// Rawurlencode preserves characters safely for data URIs
		$encoded = rawurlencode( $svg_min );
		return 'data:image/svg+xml;utf8,' . $encoded;
	}
}

/* ------------------------------------------------------------------------
 * Output favicon link tags in head using data URI for maximum portability
 * ----------------------------------------------------------------------*/
if ( ! function_exists( 'hsbp_output_favicon_head' ) ) {
	function hsbp_output_favicon_head() {
		global $hsbp_svg_favicon;
		$svg_uri = hsbp_svg_to_data_uri( $hsbp_svg_favicon );

		// Primary SVG favicon
		echo '<link rel="icon" type="image/svg+xml" href="' . esc_url( $svg_uri ) . '">' . "\n";

		// Apple touch fallback using same SVG encoded as PNG is not possible here without creating file.
		// Provide comment and let developers add apple-touch-icon.png to theme if desired.
		echo '<!-- To add apple-touch-icon or PNG fallbacks, export PNGs from the transparent SVG and place them in your theme assets -->' . "\n";
	}
	add_action( 'wp_head', 'hsbp_output_favicon_head', 1 );
}

/* ------------------------------------------------------------------------
 * Logo markup helper: returns HTML for logo (horizontal by default).
 * Uses theme custom logo if set; otherwise returns plugin-embedded horizontal SVG inline.
 * Accepts optional args array:
 *  - variant: 'horizontal'|'transparent'|'primary'
 *  - max_height: css max-height (px or rem)
 *  - aria_label: alt / aria-label text
 * ----------------------------------------------------------------------*/
if ( ! function_exists( 'hs_get_logo_markup' ) ) {
	function hs_get_logo_markup( $args = array() ) {
		global $hsbp_svg_logo_horizontal, $hsbp_svg_logo_transparent, $hsbp_svg_logo_primary;

		$defaults = array(
			'variant'    => 'horizontal', // horizontal | transparent | primary
			'max_height' => '60px',
			'aria_label' => get_bloginfo( 'name' ),
			'link'       => home_url( '/' ),
		);
		$r = wp_parse_args( $args, $defaults );

		// If the theme has a custom logo set in Customizer, return it (best practice)
		if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
			return get_custom_logo();
		}

		// Choose SVG by variant
		switch ( $r['variant'] ) {
			case 'transparent':
				$svg = $hsbp_svg_logo_transparent;
				break;
			case 'primary':
				$svg = $hsbp_svg_logo_primary;
				break;
			case 'horizontal':
			default:
				$svg = $hsbp_svg_logo_horizontal;
				break;
		}

		// Inline SVG markup wrapped in link for best accessibility and crisp rendering
		$markup  = '<a class="hsbp-site-branding" href="' . esc_url( $r['link'] ) . '" title="' . esc_attr( get_bloginfo( 'name' ) ) . '" aria-label="' . esc_attr( $r['aria_label'] ) . '">';
		// We can wrap the svg in a container that constrains height with CSS
		$markup .= '<span class="hsbp-logo-wrap" style="display:inline-block;max-height:' . esc_attr( $r['max_height'] ) . ';line-height:1;">';
		$markup .= $svg;
		$markup .= '</span>';
		$markup .= '</a>';

		return $markup;
	}
}

/* Convenience function that echoes the markup */
if ( ! function_exists( 'hs_the_logo' ) ) {
	function hs_the_logo( $args = array() ) {
		echo hs_get_logo_markup( $args );
	}
}

/* Backwards-compatible name from earlier examples */
if ( ! function_exists( 'hsbp_get_logo_markup' ) ) {
	function hsbp_get_logo_markup( $args = array() ) {
		return hs_get_logo_markup( $args );
	}
}
if ( ! function_exists( 'hsbp_the_logo' ) ) {
	function hsbp_the_logo( $args = array() ) {
		echo hsbp_get_logo_markup( $args );
	}
}

/* ------------------------------------------------------------------------
 * Shortcode: [hsbp_logo] usage: [hsbp_logo variant="horizontal" max_height="60px"]
 * ----------------------------------------------------------------------*/
if ( ! function_exists( 'hsbp_logo_shortcode' ) ) {
	function hsbp_logo_shortcode( $atts ) {
		$atts = shortcode_atts( array(
			'variant'    => 'horizontal',
			'max_height' => '60px',
			'link'       => home_url( '/' ),
		), $atts, 'hsbp_logo' );

		return hs_get_logo_markup( array(
			'variant'    => $atts['variant'],
			'max_height' => $atts['max_height'],
			'link'       => $atts['link'],
		) );
	}
	add_shortcode( 'hsbp_logo', 'hsbp_logo_shortcode' );
}

/* ------------------------------------------------------------------------
 * Optional: enqueue minimal CSS to keep logos responsive and visually consistent
 * This is lightweight and will not conflict with theme styles in most cases.
 * You can remove or override by adding CSS to your theme.
 * ----------------------------------------------------------------------*/
if ( ! function_exists( 'hsbp_enqueue_inline_styles' ) ) {
	function hsbp_enqueue_inline_styles() {
		$css = "
		/* HIGHSTREET OFFICIAL — embedded logo styles */
		.hsbp-site-branding { display: inline-block; text-decoration: none; }
		.hsbp-site-branding img { max-height: 60px; height: auto; width: auto; }
		.hsbp-logo-wrap svg { height: 100%; width: auto; display: block; }
		";
		wp_register_style( 'hsbp-inline', false );
		wp_enqueue_style( 'hsbp-inline' );
		wp_add_inline_style( 'hsbp-inline', $css );
	}
	add_action( 'wp_enqueue_scripts', 'hsbp_enqueue_inline_styles', 20 );
}

/* ------------------------------------------------------------------------
 * Example: automatic replacement of default theme logo area (OPTIONAL)
 * If your theme prints a function called 'the_custom_logo' or uses 'site-branding' class,
 * you can optionally auto-hook into 'wp_head' or a specific action. We don't enable anything destructive here.
 * ----------------------------------------------------------------------*/

/* End of file */