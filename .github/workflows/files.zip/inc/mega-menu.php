<?php
/**
 * Mega menu registration and helpers
 */

/**
 * Example: register a walker or helper to render mega menu markup
 * Implement a custom walker if you need multi-column menu panels
 */

if ( ! function_exists( 'hs_register_menu_locations' ) ) {
    function hs_register_menu_locations() {
        register_nav_menu( 'mega', __( 'Mega Menu', 'highstreet-official' ) );
    }
    add_action( 'init', 'hs_register_menu_locations' );
}