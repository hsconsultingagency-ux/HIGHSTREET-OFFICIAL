<?php
/**
 * HIGHSTREET OFFICIAL — Write brand SVGs into a web subdirectory (one-file installer)
 *
 * Installation:
 * 1. Put this file in your active theme: /wp-content/themes/your-theme/inc/highstreet-brand-writer.php
 * 2. Add this line in your theme's functions.php:
 *      require_once get_stylesheet_directory() . '/inc/highstreet-brand-writer.php';
 * 3. Edit $hsbp_relative_subdir below to the path you want (relative to WP root), then visit WP admin Dashboard once.
 *
 * Example values for $hsbp_relative_subdir:
 *  - 'wp-content/themes/your-theme/assets/highstreet-brand'  (recommended)
 *  - 'wp-content/uploads/hs-brand'                         (public, persisted)
 *  - 'hs-assets'                                           (public, at https://yourdomain.com/hs-assets)
 *
 * Notes:
 * - The target folder must be writable by the webserver or the file writes will fail.
 * - This runs once and sets an option to avoid overwriting later. To force re-run, delete the option 'hsbp_assets_written'.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* === CONFIG — set the web-accessible relative path you want ===
   Replace this with the exact relative path you want on your server */
$hsbp_relative_subdir = 'wp-content/themes/your-theme/assets/highstreet-brand'; // <-- EDIT THIS

/* === END CONFIG === */

add_action( 'admin_init', function() use ( $hsbp_relative_subdir ) {

    // only run once
    if ( get_option( 'hsbp_assets_written' ) ) {
        return;
    }

    // resolve filesystem absolute path and URL
    $abs_path = untrailingslashit( ABSPATH ) . '/' . ltrim( $hsbp_relative_subdir, '/' );
    $url_path = untrailingslashit( site_url( '/' ) ) . '/' . ltrim( $hsbp_relative_subdir, '/' );

    // attempt to create directory
    if ( ! wp_mkdir_p( $abs_path ) ) {
        // could not create directory — add admin notice to inform user
        add_action( 'admin_notices', function() use ( $abs_path ) {
            echo '<div class="notice notice-error"><p><strong>HIGHSTREET ASSETS:</strong> Could not create target folder: <code>' . esc_html( $abs_path ) . '</code>. Check file permissions or create the folder manually and make it writable.</p></div>';
        } );
        return;
    }

    // SVG contents (kept compact). You may replace these strings if you have custom art.
    $logo_horizontal = '<?xml version="1.0" encoding="utf-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2000 600"><defs><linearGradient id="gH" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#f5dd9a"/><stop offset="100%" stop-color="#b6862a"/></linearGradient></defs><g transform="translate(60,40) scale(0.9)"><path d="M80 60 h160 l20 210 a10 10 0 0 1 -10 12 H70 a10 10 0 0 1 -10 -12 z" fill="url(#gH)" stroke="#8f6b2b" stroke-width="4" stroke-linejoin="round"/><path d="M110 60 q40 -45 120 0" fill="none" stroke="#cf9f45" stroke-width="10" stroke-linecap="round"/></g><text x="420" y="180" font-family="Cinzel, Georgia, serif" font-size="96" fill="#d9b46a" font-weight="700" letter-spacing="5">HIGHSTREET</text><text x="420" y="260" font-family="Cinzel, Georgia, serif" font-size="40" fill="#e7c87f" letter-spacing="8">OFFICIAL</text></svg>';

    $logo_transparent = '<?xml version="1.0" encoding="utf-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 1200"><defs><linearGradient id="gT" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#f6e0ae"/><stop offset="50%" stop-color="#d8b25a"/><stop offset="100%" stop-color="#b6862a"/></linearGradient></defs><g transform="translate(300,150)"><path d="M150 120 h300 l40 420 a20 20 0 0 1 -20 24 H130 a20 20 0 0 1 -20 -24 z" fill="url(#gT)" stroke="#a67c2e" stroke-width="5" stroke-linejoin="round"/><circle cx="190" cy="80" r="16" fill="#b78b33"/><circle cx="410" cy="80" r="16" fill="#b78b33"/><path d="M200 80 q60 -70 200 0" fill="none" stroke="#cf9e44" stroke-width="14" stroke-linecap="round"/></g><text x="600" y="760" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-size="110" fill="#cfaE6a" font-weight="700" letter-spacing="6">HIGHSTREET</text><text x="600" y="860" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-size="48" fill="#e0c480" letter-spacing="10">OFFICIAL</text></svg>';

    $logo_primary = '<?xml version="1.0" encoding="utf-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 1200"><defs><linearGradient id="gP" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#f5dd9a"/><stop offset="50%" stop-color="#d8b25a"/><stop offset="100%" stop-color="#b6862a"/></linearGradient></defs><rect width="100%" height="100%" fill="#0b0b0b"/><g transform="translate(300,150)"><path d="M150 120 h300 l40 420 a20 20 0 0 1 -20 24 H130 a20 20 0 0 1 -20 -24 z" fill="url(#gP)" stroke="#8f6b2b" stroke-width="6" stroke-linejoin="round"/><circle cx="190" cy="80" r="18" fill="#b38633"/><circle cx="410" cy="80" r="18" fill="#b38633"/><path d="M200 80 q60 -70 200 0" fill="none" stroke="#cf9f45" stroke-width="18" stroke-linecap="round"/></g><text x="600" y="760" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-size="110" fill="#d9b46a" font-weight="700" letter-spacing="6">HIGHSTREET</text><text x="600" y="860" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-size="48" fill="#e7c87f" letter-spacing="10">OFFICIAL</text></svg>';

    $favicon_svg = '<?xml version="1.0" encoding="utf-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="gFav" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#f5dd9a"/><stop offset="100%" stop-color="#b6862a"/></linearGradient></defs><rect width="64" height="64" rx="8" fill="#0b0b0b"/><g transform="translate(8,6)" fill="url(#gFav)"><rect x="6" y="10" width="36" height="30" rx="4"/><path d="M12 10 q8 -11 24 0" fill="none" stroke="url(#gFav)" stroke-width="3" stroke-linecap="round"/></g></svg>';

    // target filenames
    $files = array(
        'logo-horizontal.svg' => $logo_horizontal,
        'logo-transparent.svg' => $logo_transparent,
        'logo-primary.svg' => $logo_primary,
        'favicon.svg' => $favicon_svg,
    );

    $written = array();
    foreach ( $files as $filename => $contents ) {
        $full = trailingslashit( $abs_path ) . $filename;
        $bytes = @file_put_contents( $full, $contents );
        if ( $bytes === false ) {
            // try WP_Filesystem fallback
            if ( function_exists( 'WP_Filesystem' ) ) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
                WP_Filesystem();
                global $wp_filesystem;
                if ( isset( $wp_filesystem ) && method_exists( $wp_filesystem, 'put_contents' ) ) {
                    $ok = $wp_filesystem->put_contents( $full, $contents, FS_CHMOD_FILE );
                    if ( $ok ) {
                        $written[] = $filename;
                        continue;
                    }
                }
            }

            // failed to write this file
            add_action( 'admin_notices', function() use ( $full ) {
                echo '<div class="notice notice-error"><p><strong>HIGHSTREET ASSETS:</strong> Could not write file: <code>' . esc_html( $full ) . '</code>. Check folder permissions.</p></div>';
            } );
            // continue trying other files
        } else {
            $written[] = $filename;
        }
    }

    if ( ! empty( $written ) ) {
        update_option( 'hsbp_assets_written', 1 );

        add_action( 'admin_notices', function() use ( $url_path, $written ) {
            echo '<div class="notice notice-success"><p><strong>HIGHSTREET ASSETS:</strong> Wrote ' . esc_html( implode( ', ', $written ) ) . ' to <code>' . esc_html( $url_path ) . '</code></p>';
            echo '<p>Accessible URLs:</p><ul>';
            foreach ( $written as $f ) {
                echo '<li><a href="' . esc_url( untrailingslashit( site_url( '/' ) ) . '/' . str_replace( ABSPATH, '', trailingslashit( untrailingslashit( ABSPATH ) ) . ltrim( str_replace( untrailingslashit( ABSPATH ), '', $url_path ), '/' ) . '/' . $f ) ) . '">' . esc_html( $f ) . '</a></li>';
            }
            echo '</ul></div>';
        } );
    }

}, 5 );