<?php
/**
 * HIGHSTREET OFFICIAL — Write brand SVGs into wp-content/uploads/hs-brand and add helper functions
 *
 * Installation:
 * 1) Copy this file to your active theme folder:
 *      /wp-content/themes/your-active-theme/inc/highstreet-brand-writer-wp-uploads.php
 *    (create the 'inc' folder if it doesn't exist)
 * 2) Add one line to your theme's functions.php to load it:
 *      require_once get_stylesheet_directory() . '/inc/highstreet-brand-writer-wp-uploads.php';
 * 3) Visit any WP Admin screen (Dashboard) once to trigger the file creation. You'll see an admin notice showing results.
 *
 * Behavior:
 * - Creates directory: wp-content/uploads/hs-brand
 * - Writes four SVG files:
 *     logo-horizontal.svg
 *     logo-transparent.svg
 *     logo-primary.svg
 *     favicon.svg
 * - Adds helper functions:
 *     hsbp_get_logo_markup( $args )  -> returns HTML (variant: horizontal|transparent|primary)
 *     hsbp_the_logo( $args )        -> echoes HTML
 * - Outputs favicon link tags in <head> pointing to the created assets
 * - Runs once (stores an option 'hsbp_assets_written') and will not overwrite files unless you delete that option
 *
 * Notes:
 * - Target uploads folder must be writable by WordPress (typical for wp-content/uploads).
 * - After confirming files were created, you may remove this include line from functions.php OR keep it — it is safe.
 */

/* Prevent direct access */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* === CONFIG: target relative path (relative to WP root) === */
if ( ! defined( 'HSBP_RELATIVE_DIR' ) ) {
	define( 'HSBP_RELATIVE_DIR', 'wp-content/uploads/hs-brand' );
}

/* Helper to return absolute filesystem path for assets directory */
if ( ! function_exists( 'hsbp_get_assets_abs_path' ) ) {
	function hsbp_get_assets_abs_path() {
		return untrailingslashit( ABSPATH ) . '/' . ltrim( HSBP_RELATIVE_DIR, '/' );
	}
}

/* Helper to return public URL for assets directory */
if ( ! function_exists( 'hsbp_get_assets_url' ) ) {
	function hsbp_get_assets_url() {
		return untrailingslashit( site_url( '/' ) ) . '/' . ltrim( HSBP_RELATIVE_DIR, '/' );
	}
}

/* Create and write assets once on admin_init */
add_action( 'admin_init', function() {

	if ( get_option( 'hsbp_assets_written', false ) ) {
		return;
	}

	$abs_path = hsbp_get_assets_abs_path();
	$url_path = hsbp_get_assets_url();

	// Create directory (wp_mkdir_p will create parents)
	if ( ! wp_mkdir_p( $abs_path ) ) {
		add_action( 'admin_notices', function() use ( $abs_path ) {
			echo '<div class="notice notice-error"><p><strong>HIGHSTREET ASSETS:</strong> Could not create folder <code>' . esc_html( $abs_path ) . '</code>. Check file permissions (webserver must be able to write to wp-content/uploads).</p></div>';
		} );
		return;
	}

	// SVG contents (compact single-line strings)
	$files = array(
		'logo-horizontal.svg'  => '<?xml version="1.0" encoding="utf-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2000 600"><defs><linearGradient id="gH" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#f5dd9a"/><stop offset="100%" stop-color="#b6862a"/></linearGradient></defs><g transform="translate(60,40) scale(0.9)"><path d="M80 60 h160 l20 210 a10 10 0 0 1 -10 12 H70 a10 10 0 0 1 -10 -12 z" fill="url(#gH)" stroke="#8f6b2b" stroke-width="4" stroke-linejoin="round"/><path d="M110 60 q40 -45 120 0" fill="none" stroke="#cf9f45" stroke-width="10" stroke-linecap="round"/></g><text x="420" y="180" font-family="Cinzel, Georgia, serif" font-size="96" fill="#d9b46a" font-weight="700" letter-spacing="5">HIGHSTREET</text><text x="420" y="260" font-family="Cinzel, Georgia, serif" font-size="40" fill="#e7c87f" letter-spacing="8">OFFICIAL</text></svg>',
		'logo-transparent.svg' => '<?xml version="1.0" encoding="utf-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 1200"><defs><linearGradient id="gT" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#f6e0ae"/><stop offset="50%" stop-color="#d8b25a"/><stop offset="100%" stop-color="#b6862a"/></linearGradient></defs><g transform="translate(300,150)"><path d="M150 120 h300 l40 420 a20 20 0 0 1 -20 24 H130 a20 20 0 0 1 -20 -24 z" fill="url(#gT)" stroke="#a67c2e" stroke-width="5" stroke-linejoin="round"/><circle cx="190" cy="80" r="16" fill="#b78b33"/><circle cx="410" cy="80" r="16" fill="#b78b33"/><path d="M200 80 q60 -70 200 0" fill="none" stroke="#cf9e44" stroke-width="14" stroke-linecap="round"/></g><text x="600" y="760" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-size="110" fill="#cfaE6a" font-weight="700" letter-spacing="6">HIGHSTREET</text><text x="600" y="860" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-size="48" fill="#e0c480" letter-spacing="10">OFFICIAL</text></svg>',
		'logo-primary.svg'     => '<?xml version="1.0" encoding="utf-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 1200"><defs><linearGradient id="gP" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#f5dd9a"/><stop offset="50%" stop-color="#d8b25a"/><stop offset="100%" stop-color="#b6862a"/></linearGradient></defs><rect width="100%" height="100%" fill="#0b0b0b"/><g transform="translate(300,150)"><path d="M150 120 h300 l40 420 a20 20 0 0 1 -20 24 H130 a20 20 0 0 1 -20 -24 z" fill="url(#gP)" stroke="#8f6b2b" stroke-width="6" stroke-linejoin="round"/><circle cx="190" cy="80" r="18" fill="#b38633"/><circle cx="410" cy="80" r="18" fill="#b38633"/><path d="M200 80 q60 -70 200 0" fill="none" stroke="#cf9f45" stroke-width="18" stroke-linecap="round"/></g><text x="600" y="760" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-size="110" fill="#d9b46a" font-weight="700" letter-spacing="6">HIGHSTREET</text><text x="600" y="860" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-size="48" fill="#e7c87f" letter-spacing="10">OFFICIAL</text></svg>',
		'favicon.svg'          => '<?xml version="1.0" encoding="utf-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="gFav" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#f5dd9a"/><stop offset="100%" stop-color="#b6862a"/></linearGradient></defs><rect width="64" height="64" rx="8" fill="#0b0b0b"/><g transform="translate(8,6)" fill="url(#gFav)"><rect x="6" y="10" width="36" height="30" rx="4"/><path d="M12 10 q8 -11 24 0" fill="none" stroke="url(#gFav)" stroke-width="3" stroke-linecap="round"/></g></svg>',
	);

	$written = array();

	// Attempt to write files; try direct file_put_contents first, fallback to WP_Filesystem
	foreach ( $files as $filename => $contents ) {
		$full = trailingslashit( $abs_path ) . $filename;
		$result = @file_put_contents( $full, $contents );

		if ( $result === false ) {
			// Try WP_Filesystem (handles environments where PHP can't write directly)
			require_once ABSPATH . 'wp-admin/includes/file.php';
			global $wp_filesystem;
			WP_Filesystem();
			if ( isset( $wp_filesystem ) && method_exists( $wp_filesystem, 'put_contents' ) ) {
				$ok = $wp_filesystem->put_contents( $full, $contents, FS_CHMOD_FILE );
				if ( $ok ) {
					$written[] = $filename;
					continue;
				}
			}

			// if we get here, failed to write file
			add_action( 'admin_notices', function() use ( $full ) {
				echo '<div class="notice notice-error"><p><strong>HIGHSTREET ASSETS:</strong> Could not write file <code>' . esc_html( $full ) . '</code>. Please check permissions.</p></div>';
			} );
			continue;
		}

		$written[] = $filename;
	}

	if ( ! empty( $written ) ) {
		// Mark as done (store written file list for debugging if needed)
		update_option( 'hsbp_assets_written', 1 );
		update_option( 'hsbp_assets_written_files', $written );

		// Success notice showing public URLs
		add_action( 'admin_notices', function() use ( $url_path, $written ) {
			echo '<div class="notice notice-success"><p><strong>HIGHSTREET ASSETS:</strong> Wrote ' . esc_html( implode( ', ', $written ) ) . ' to <code>' . esc_html( HSBP_RELATIVE_DIR ) . '</code>.</p>';
			echo '<p>Public URLs:</p><ul style="margin:6px 0;">';
			foreach ( $written as $f ) {
				$u = untrailingslashit( site_url( '/' ) ) . '/' . ltrim( HSBP_RELATIVE_DIR, '/' ) . '/' . rawurlencode( $f );
				echo '<li><a href="' . esc_url( $u ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $u ) . '</a></li>';
			}
			echo '</ul><p>If you want to re-run the writer, delete the option <code>hsbp_assets_written</code> in the database (or use a transient plugin).</p></div>';
		} );
	}

}, 5 );

/* ---------------------------------------------------------------------
 * Output favicon <link> tags in front-end head (SVG + optional PNG fallback)
 * -------------------------------------------------------------------*/
add_action( 'wp_head', function() {
	$assets_url = hsbp_get_assets_url();
	$assets_abs = hsbp_get_assets_abs_path();

	$svg_url = $assets_url . '/favicon.svg';
	echo '<link rel="icon" type="image/svg+xml" href="' . esc_url( $svg_url ) . '">' . "\n";

	// PNG fallback if present (favicon-32.png)
	$png32_abs = trailingslashit( $assets_abs ) . 'favicon-32.png';
	if ( file_exists( $png32_abs ) ) {
		echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( $assets_url . '/favicon-32.png' ) . '">' . "\n";
	}
}, 1 );

/* ---------------------------------------------------------------------
 * Logo helper: hsbp_get_logo_markup() and hsbp_the_logo()
 * - $args: 'variant' => 'horizontal'|'transparent'|'primary', 'max_height' => '60px'
 * -------------------------------------------------------------------*/
if ( ! function_exists( 'hsbp_get_logo_markup' ) ) {
	function hsbp_get_logo_markup( $args = array() ) {
		$defaults = array(
			'variant'    => 'horizontal',
			'max_height' => '60px',
			'aria_label' => get_bloginfo( 'name' ),
			'link'       => home_url( '/' ),
		);
		$r = wp_parse_args( $args, $defaults );

		// If theme has a custom logo set in Customizer, prefer that
		if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
			return get_custom_logo();
		}

		$filename = 'logo-horizontal.svg';
		if ( 'transparent' === $r['variant'] ) {
			$filename = 'logo-transparent.svg';
		} elseif ( 'primary' === $r['variant'] ) {
			$filename = 'logo-primary.svg';
		}

		$src = hsbp_get_assets_url() . '/' . rawurlencode( $filename );

		$markup  = '<a class="hsbp-site-branding" href="' . esc_url( $r['link'] ) . '" aria-label="' . esc_attr( $r['aria_label'] ) . '">';
		$markup .= '<img src="' . esc_url( $src ) . '" alt="' . esc_attr( $r['aria_label'] ) . '" style="max-height:' . esc_attr( $r['max_height'] ) . '; height:auto; width:auto; display:inline-block;">';
		$markup .= '</a>';

		return $markup;
	}
}

if ( ! function_exists( 'hsbp_the_logo' ) ) {
	function hsbp_the_logo( $args = array() ) {
		echo hsbp_get_logo_markup( $args );
	}
}

/* Backwards-compatible names */
if ( ! function_exists( 'hs_get_logo_markup' ) ) {
	function hs_get_logo_markup( $args = array() ) {
		return hsbp_get_logo_markup( $args );
	}
}
if ( ! function_exists( 'hs_the_logo' ) ) {
	function hs_the_logo( $args = array() ) {
		echo hsbp_get_logo_markup( $args );
	}
}

/* ---------------------------------------------------------------------
 * Shortcode: [hsbp_logo variant="horizontal" max_height="60px"]
 * -------------------------------------------------------------------*/
add_shortcode( 'hsbp_logo', function( $atts ) {
	$atts = shortcode_atts( array(
		'variant'    => 'horizontal',
		'max_height' => '60px',
		'link'       => home_url( '/' ),
	), $atts, 'hsbp_logo' );

	return hsbp_get_logo_markup( array(
		'variant'    => $atts['variant'],
		'max_height' => $atts['max_height'],
		'link'       => $atts['link'],
	) );
} );

/* ---------------------------------------------------------------------
 * Tiny inline CSS for safe defaults (optional; easily overridden by theme)
 * -------------------------------------------------------------------*/
add_action( 'wp_enqueue_scripts', function() {
	$css = "
	.hsbp-site-branding{display:inline-block;text-decoration:none}
	.hsbp-site-branding img{max-height:60px;height:auto;width:auto;display:inline-block}
	";
	wp_register_style( 'hsbp-inline', false );
	wp_enqueue_style( 'hsbp-inline' );
	wp_add_inline_style( 'hsbp-inline', $css );
}, 20 );

/* End of file */