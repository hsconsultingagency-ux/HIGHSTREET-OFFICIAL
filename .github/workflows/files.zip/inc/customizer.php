<?php
/**
 * Customizer options
 */

if ( ! function_exists( 'hs_customizer_register' ) ) {
    function hs_customizer_register( $wp_customize ) {
        $wp_customize->add_section( 'hs_header', array(
            'title'    => __( 'Header Settings', 'highstreet-official' ),
            'priority' => 30,
        ) );

        $wp_customize->add_setting( 'hs_logo', array(
            'sanitize_callback' => 'absint',
        ) );

        $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'hs_logo', array(
            'label'    => __( 'Logo', 'highstreet-official' ),
            'section'  => 'hs_header',
            'settings' => 'hs_logo',
        ) ) );
    }
    add_action( 'customize_register', 'hs_customizer_register' );
}