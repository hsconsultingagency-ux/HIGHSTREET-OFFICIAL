# HIGHSTREET OFFICIAL — Brand Package (Plugin)

Install as a single ZIP file via WordPress Plugins → Add New → Upload Plugin.

What this plugin does:
- Provides 4 SVG assets in plugin `assets/`:
  - logo-primary.svg
  - logo-transparent.svg
  - logo-horizontal.svg
  - favicon.svg
- Outputs favicon link tags in the site <head>.
- Exposes helper functions:
  - hsbp_get_logo_markup() — returns logo HTML (uses theme custom logo if set, otherwise plugin horizontal SVG)
  - hsbp_the_logo() — echoes logo HTML

How to use in your theme:
- In your theme header (templates/header.php) replace logo area with:
  <?php echo hsbp_get_logo_markup(); ?>

Recommended extra steps (optional):
- Export PNG/ICO fallback images using ImageMagick if you need raster fallbacks for older platforms:
  magick assets/logo-transparent.svg -background none -resize 1200x1200 assets/logo-1200.png
  magick assets/logo-transparent.svg -background none -resize 600x600 assets/logo-600.png
  magick assets/logo-transparent.svg -background none -resize 300x300 assets/logo-300.png
  magick assets/logo-transparent.svg -background none -resize 64x64 assets/favicon-64.png
  magick assets/logo-transparent.svg -background none -resize 32x32 assets/favicon-32.png

Security note:
- WordPress blocks raw SVG uploads to media by default. This plugin keeps SVGs inside its own folder and serves them as static assets (safe). If you want SVGs in Media Library, use a sanitizing SVG plugin.