<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Return markup for the logo.
 * If the theme has a custom logo set in the Customizer it will be used.
 * Otherwise it falls back to plugin-provided horizontal SVG.
 */
function hsbp_get_logo_markup() {
    // If theme has custom logo, use it
    if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
        return get_custom_logo();
    }

    // Fallback: plugin horizontal SVG
    $logo_url = HSBP_URL . 'assets/logo-horizontal.svg';
    $html  = '<a class="hsbp-site-branding" href="' . esc_url( home_url( '/' ) ) . '" title="' . esc_attr( get_bloginfo( 'name' ) ) . '">';
    $html .= '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" style="max-height:60px; height:auto; width:auto;">';
    $html .= '</a>';

    return $html;
}

/**
 * Echo markup (convenience)
 */
function hsbp_the_logo() {
    echo hsbp_get_logo_markup();
}