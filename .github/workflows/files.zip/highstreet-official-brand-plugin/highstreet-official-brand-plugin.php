<?php
/*
Plugin Name: HIGHSTREET OFFICIAL — Brand Package
Description: Adds HIGHSTREET OFFICIAL brand assets (SVG logos, favicon) and provides helper functions to output the logo and favicon links. Install via Plugins > Add New > Upload Plugin.
Version: 1.0.0
Author: HS Consulting Agency
Text Domain: highstreet-official-brand
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'HSBP_DIR', plugin_dir_path( __FILE__ ) );
define( 'HSBP_URL', plugin_dir_url( __FILE__ ) );

// Load helper functions
require_once HSBP_DIR . 'includes/helpers.php';

/**
 * Output plugin favicon links in <head>
 * Fallbacks included: SVG and 32x32 PNG if provided in assets/
 */
function hsbp_output_favicon() {
    // SVG favicon
    $svg = HSBP_URL . 'assets/favicon.svg';
    echo '<link rel="icon" type="image/svg+xml" href="' . esc_url( $svg ) . '">' . "\n";

    // PNG fallback (32x32) - if you add a PNG named favicon-32.png to assets, it will be used
    $png32 = HSBP_URL . 'assets/favicon-32.png';
    // We don't check file_exists on URL; browsers will simply 404 if not present (safe).
    echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( $png32 ) . '">' . "\n";

    // Apple touch icon fallback (optional)
    $apple = HSBP_URL . 'assets/apple-touch-icon.png';
    echo '<link rel="apple-touch-icon" href="' . esc_url( $apple ) . '">' . "\n";
}
add_action( 'wp_head', 'hsbp_output_favicon', 1 );

/**
 * Register a simple options page under Tools for quick instructions (no settings saved)
 */
function hsbp_tools_page() {
    add_management_page(
        __( 'HS Brand Package', 'highstreet-official-brand' ),
        'HS Brand Package',
        'manage_options',
        'hsbp-brand-package',
        'hsbp_tools_render'
    );
}
add_action( 'admin_menu', 'hsbp_tools_page' );

function hsbp_tools_render() {
    ?>
    <div class="wrap">
        <h1>HIGHSTREET OFFICIAL — Brand Package</h1>
        <p>This plugin provides branded SVG assets and helper functions.</p>
        <h2>Usage</h2>
        <ol>
            <li>Place <code>echo hsbp_get_logo_markup();</code> in your theme header where you want the logo to appear (fallback used if theme has no custom logo).</li>
            <li>Uploaded assets are located at: <code><?php echo esc_html( HSBP_URL . 'assets/' ); ?></code></li>
        </ol>
        <h2>Files included</h2>
        <ul>
            <li>logo-primary.svg — hero / large use on dark background</li>
            <li>logo-transparent.svg — transparent background, flexible</li>
            <li>logo-horizontal.svg — header / nav</li>
            <li>favicon.svg — favicon (SVG) and placeholders for PNG variants</li>
            <li>README (in plugin folder) — further export instructions</li>
        </ul>
        <h2>Next steps</h2>
        <p>To use a PNG fallback for the favicon or apple-touch-icon, add <code>favicon-32.png</code> or <code>apple-touch-icon.png</code> to the plugin <code>assets/</code> folder and refresh the front-end.</p>
    </div>
    <?php
}